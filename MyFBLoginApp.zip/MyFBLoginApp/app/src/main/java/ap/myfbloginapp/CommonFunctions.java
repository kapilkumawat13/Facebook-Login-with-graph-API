package ap.myfbloginapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class CommonFunctions {

    public static File file = null;
    public static File dir = null;
    public static File root = null;
    Dialog alertDialog;

    public static void AboutBox(String Msg, Context con) {
        new AlertDialog.Builder(con).setTitle(con.getResources().getString(R.string.alert)).setMessage(Msg)
                .setPositiveButton(con.getResources().getString(R.string.ok), null).show();
    }

    public static void AboutBoxWithFinishActivity(String Msg, final Context con) {
        new AlertDialog.Builder(con).setTitle(con.getResources().getString(R.string.alert)).setMessage(Msg)
                .setPositiveButton("OK", new OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub

                        ((Activity) con).finish();
                        dialog.dismiss();
                        //((Activity) con).finish();

                    }
                }).show();

    }




    public static boolean haveInternet(Context ctx) {

        NetworkInfo info = (NetworkInfo) ((ConnectivityManager) ctx
                .getSystemService(Context.CONNECTIVITY_SERVICE))
                .getActiveNetworkInfo();

        if (info == null || !info.isConnected()) {
            return false;
        }
        if (info.isRoaming()) {
            // here is the roaming option you can change it if you want to
            // disable internet while roaming, just return false
            return false;
        }
        return true;
    }





}
