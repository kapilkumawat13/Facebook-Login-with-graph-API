package ap.myfbloginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

/**
 * Created by kapil on 12/7/16.
 */
public class MainActivity extends AppCompatActivity {

    ImageView imgFacebook;
    LoginManager loginManager;
    List<String> permissionNeeds = Arrays.asList("email", "user_birthday", "user_friends", "public_profile");
    String s_email = "";
    CallbackManager callbackManager;
    ImageView IV_profile_FB;
    TextView TV_Name, TV_Email, TV_Bday, TV_Id, TV_Gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(this);
        setContentView(R.layout.activity_main);
        IV_profile_FB = (ImageView) findViewById(R.id.IV_profile_FB);
        TV_Name = (TextView) findViewById(R.id.TV_Name);
        TV_Email = (TextView) findViewById(R.id.TV_Email);
        TV_Bday = (TextView) findViewById(R.id.TV_Bday);
        TV_Id = (TextView) findViewById(R.id.TV_Id);
        TV_Gender = (TextView) findViewById(R.id.TV_Gender);
        imgFacebook = (ImageView) findViewById(R.id.imgFacebook);
        imgFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                facebookLogin();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    String profilePicUrl = "";
    public void facebookLogin() {
        try {
            loginManager.getInstance().logOut();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (CommonFunctions.haveInternet(getApplicationContext())) {

            callbackManager = CallbackManager.Factory.create();
            LoginManager.getInstance().logInWithReadPermissions(MainActivity.this, permissionNeeds);
            LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
                @Override
                public void onSuccess(LoginResult loginResults) {

                    GraphRequest request = GraphRequest.newMeRequest(
                            loginResults.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                                @Override
                                public void onCompleted(JSONObject object, GraphResponse response) {
                                    // Application code
                                    Log.v("LoginActivity", response.toString());

                                    Log.e("response from fb>>>>", response + "");

                                    s_email = object.optString("email");
                                    Log.e("fb user email..", s_email + "");

                                    String email = object.optString("email");
                                    String uid = object.optString("id");
                                    String name = object.optString("name");
                                    String date = object.optString("birthday");
                                    String id = object.optString("id");
                                    String gender = object.optString("gender");

                                    try {
                                        JSONObject data = response.getJSONObject();
                                        if (data.has("picture")) {
                                            profilePicUrl = data.getJSONObject("picture").getJSONObject("data").getString("url");
                                            // set profile image to imageview using Picasso or Native methods
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    Log.e("profileImageURL>>>", profilePicUrl);
                                    TV_Name.setText(name);
                                    TV_Email.setText(email);
                                    TV_Bday.setText(date);
                                    TV_Id.setText(id);
                                    TV_Gender.setText(gender);
                                    final ImageLoader imageLoader = ImageLoader.getInstance();
                                    imageLoader.init(ImageLoaderConfiguration.createDefault(MainActivity.this));
                                    final DisplayImageOptions options = new DisplayImageOptions.Builder().cacheInMemory(true)
                                            .cacheOnDisc(true).resetViewBeforeLoading(true)
                                            .showImageForEmptyUri(R.drawable.com_facebook_profile_picture_blank_square)
                                            .showImageOnFail(R.drawable.com_facebook_profile_picture_blank_square)
                                            .showImageOnLoading(R.drawable.com_facebook_profile_picture_blank_square).build();

                                    //download and display image from url
                                    imageLoader.displayImage(profilePicUrl, IV_profile_FB, options);
                                    // Toast.makeText(getApplicationContext(), object.toString(), Toast.LENGTH_LONG).show();
                                    Log.e("object from fb>>", "object from fb>>" + object.toString() + "");
                                }
                            });
                    Bundle parameters = new Bundle();
                    parameters.putString("fields", "id,name,email,gender, birthday,picture.width(300)");
                    request.setParameters(parameters);
                    request.executeAsync();
                }
                @Override
                public void onCancel() {
                    Log.e("dd", "facebook login canceled");
                }

                @Override
                public void onError(FacebookException e) {
                    Log.e("dd", "facebook login failed error" + e.toString());
                }
            });
        } else {

            Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_internet_connection), Toast.LENGTH_LONG).show();
        }

    }

}
